vec3 getSunColor() {
   float x    = worldTime * NORMALIZE_TIME;
   float y    = x > SUNRISE ? (x - 1.0) - NOON : x - NOON;
   bool isDay = x > SUNRISE || x < SUNSET;

   vec3 dayColor    = vec3(0.90, 0.84, 0.79);
   vec3 sunsetColor = vec3(0.8875, 0.4433, 0.3010);
   vec3 nightColor  = MOON_COLOR * 0.5; 

   float sunHeight = (gbufferModelViewInverse * vec4(shadowLightPosition, 1.0)).y;
   float sunsetMix = clamp(1.0 - abs(sunHeight) / 20.0, 0.0, 1.0); 

   vec3 sunColor;
   if (isDay) {
       sunColor = mix(dayColor, sunsetColor, sunsetMix);
   } else {
       sunColor = mix(nightColor, sunsetColor, sunsetMix);
   }

   sunColor *= clamp(0.1 * sunHeight - 0.4453, 0.0, 1.0);

   return mix(vec3(length(sunColor)), sunColor, lightUV.t);
}