float getTorchStrength(float torchLight) {
   float x = rescale(torchLight, TORCH_UV_SCALE.x, TORCH_UV_SCALE.y);
   return x * sqrt(x) + pow(x, 3.0) * 0.4;
}