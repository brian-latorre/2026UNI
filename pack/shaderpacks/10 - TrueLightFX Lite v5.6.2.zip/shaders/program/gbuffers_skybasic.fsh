#define gbuffers_skybasic

#include "/shader.h"

uniform float viewHeight;
uniform float viewWidth;
uniform mat4 gbufferModelView;
uniform mat4 gbufferProjectionInverse;
uniform vec3 fogColor;
uniform int isEyeInWater;
uniform vec3 skyColor;

varying float fogMix;
varying vec4 starColor;

#include "/common/math.glsl"
#include "/common/transformations.fsh"

void main() {
	vec3 color;

	if (starColor.a > 0.9) {
		color = starColor.rgb;
	}
	else {
      vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
      vec3 screenPos = normalize(uv2screen(uv, 1.0));
      float upDot = dot(screenPos, gbufferModelView[1].xyz);

      vec3 zenithColor = skyColor * vec3(0.5, 0.6, 1.2); 
      vec3 midColor    = skyColor * vec3(0.9, 0.95, 1.1); 
      vec3 horizonColor = mix(skyColor, fogColor, 0.7) * vec3(1.1, 1.05, 1.0); 

      vec3 vibrantSky;
      if (upDot > 0.4) {
         float t = smoothstep(0.4, 1.0, upDot);
         vibrantSky = mix(midColor, zenithColor, t);
      } else {
         float t = smoothstep(0.0, 0.4, upDot);
         vibrantSky = mix(horizonColor, midColor, t);
      }

		vec3 baseFogColor = fogColor;
		#ifdef FOG_ENHANCEMENT
		   float fogLuminance = luma(fogColor);
		   vec3 goldTint = vec3(1.1, 0.95, 0.7) * fogColor;
		   baseFogColor = mix(fogColor, goldTint, smoothstep(0.3, 0.8, fogLuminance));
		#endif

		vec3 finalFogColor = mix(baseFogColor, vec3(0.02, 0.35, 0.55), float(isEyeInWater == 1) * 0.75);
		float finalFogMix  = mix(fogMix, fogMix * 0.75, float(isEyeInWater == 1));
		color = mix(vibrantSky, finalFogColor, max(finalFogMix, fogify(max(upDot, 0.0), 0.05)));
	}

   gl_FragData[0] = vec4(color, 1.0);
}
