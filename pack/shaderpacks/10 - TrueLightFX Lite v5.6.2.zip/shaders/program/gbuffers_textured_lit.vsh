#define gbuffers_textured_lit

#include "/shader.h"

attribute vec4 mc_Entity;
attribute vec2 mc_midTexCoord;

uniform float fogEnd;
uniform float fogStart;
uniform float near, far;
uniform float rainStrength;
uniform float screenBrightness;
uniform int fogShape;
uniform int isEyeInWater;
uniform float frameTimeCounter;
uniform int worldTime;
uniform mat4 gbufferModelViewInverse;
uniform sampler2D lightmap;
uniform vec3 cameraPosition;

varying float fogMix;
varying float isLava;
varying float torchStrength;
varying vec2 lightUV;
varying vec2 texUV;
varying vec3 worldPos;
varying vec4 ambient;
varying vec4 color;
varying vec3 normal;

#ifdef GLOWING_ORES
   varying float isOre;
#endif

#ifdef HIGHLIGHT_WAXED
   uniform int heldItemId;
   uniform int heldItemId2;
#endif

#include "/common/math.glsl"
#include "/common/getFogMix.vsh"
#include "/common/getAmbientColor.vsh"
#include "/common/getWorldPosition.vsh"
#include "/common/getTorchStrength.vsh"

#ifdef ENABLE_SHADOWS
   uniform vec3 shadowLightPosition;

   varying vec3 sunColor;
   varying float diffuse;

   #include "/common/getDiffuse.vsh"
   #include "/common/getSunColor.vsh"
#endif

uniform vec2 taaOffset;

void main() {
   isLava  = float(abs(mc_Entity.x - 10068.0) < 0.1);

   worldPos = getWorldPosition();
   vec4 pos = gl_Vertex;

#ifdef WAVY_PLANTS
   float isGrass = float(abs(mc_Entity.x - 10059.0) < 0.1) + float(abs(mc_Entity.x - 10015.0) < 0.1);
   float isPlant = float(abs(mc_Entity.x - 10020.0) < 0.1) + isGrass;

   float speed = mix(WIND_SPEED, GRASS_WIND_SPEED, isGrass);
   float strength = mix(WIND_STRENGTH, GRASS_WIND_STRENGTH, isGrass);
   
   float t = frameTimeCounter * speed;
   vec3 p = worldPos + cameraPosition;

   float distSq = dot(worldPos, worldPos);
   float distFade = clamp(1.0 - distSq * INV_SHADOW_MAX_DIST_SQUARED, 0.0, 1.0);

   vec2 posXZ = p.xz * 0.35 + t;
   vec2 flr = floor(posXZ);
   vec2 frc = fract(posXZ);
   frc = frc * frc * (3.0 - 2.0 * frc);

   float n00 = fract(sin(dot(flr, vec2(12.9898, 4.1414))) * 43758.5453);
   float n01 = fract(sin(dot(flr + vec2(0.0, 1.0), vec2(12.9898, 4.1414))) * 43758.5453);
   float n10 = fract(sin(dot(flr + vec2(1.0, 0.0), vec2(12.9898, 4.1414))) * 43758.5453);
   float n11 = fract(sin(dot(flr + vec2(1.0, 1.0), vec2(12.9898, 4.1414))) * 43758.5453);

   float n0 = mix(n00, n01, frc.y);
   float n1 = mix(n10, n11, frc.y);
   float noiseVal = mix(n0, n1, frc.x) - 0.5;

   vec3 wave = vec3(noiseVal, noiseVal, noiseVal);
   float gust = sin(t * 0.2 + p.x * 0.05) * WIND_GUSTINESS + (1.0 - WIND_GUSTINESS);
   
   vec2 mult = mix(vec2(0.04, 0.04), vec2(0.2, 0.08), isGrass);
   vec3 move = wave * vec3(mult, mult.x) * strength * distFade * gust * 15.0;
   
   float isTopVertex = step(gl_MultiTexCoord0.t, mc_midTexCoord.t);
   move *= mix(1.0, isTopVertex, isGrass);

   pos.xyz += (move * isPlant) * vec3(0.5, mix(0.1, -0.1, isGrass), 0.5);
#endif

   gl_Position = gl_ModelViewProjectionMatrix * pos;

   #ifdef TAA
      gl_Position.xy += taaOffset * gl_Position.w;
   #endif

   color   = gl_Color;
   texUV   = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
   lightUV = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
   normal  = gl_Normal;
   ambient = getAmbientColor();

   color.rgb = mix(color.rgb, mix(vec3(0.8, 0.5, 0.3), vec3(1.0), rescale(color.rgb, vec3(0.54), vec3(0.9))), isLava);

   #ifdef THE_END
      ambient.rgb *= END_AMBIENT + 0.02*(gl_NormalMatrix * gl_Normal).xyz;
   #endif

   #ifdef GLOWING_ORES
      isOre = float(abs(mc_Entity.x - 10014.0) < 0.1) + float(abs(mc_Entity.x - 10015.0) < 0.1);
   #endif

   #ifdef HIGHLIGHT_WAXED
      float itemMatch = float(abs(float(heldItemId) - 10041.0) < 0.1) + float(abs(float(heldItemId2) - 10041.0) < 0.1);
      float waxMatch = float(abs(mc_Entity.x - 10041.0) < 0.1);
      float waxHighlight = min(itemMatch, 1.0) * waxMatch;
      float waxPulse = sin(frameTimeCounter * 6.0) * 0.5 + 0.5;
      color.rgb += vec3(1.5, 1.0, 0.0) * waxHighlight * waxPulse;
   #endif

   float isSand = float(abs(mc_Entity.x - 10080.0) < 0.1);
   color.rgb *= mix(1.0, 0.75, isSand);  

   torchStrength = getTorchStrength(lightUV.s);
   fogMix = getFogMix(worldPos);

   #ifdef ENABLE_SHADOWS
      diffuse = getDiffuse(lightUV.t);
      sunColor = getSunColor();
   #endif
}