#define gbuffers_water

#include "/shader.h"

uniform vec3 fogColor;
uniform int isEyeInWater;
uniform sampler2D texture;

varying vec2 texUV;
varying vec2 lightUV;
varying vec3 worldPos;
varying vec4 color;
varying vec4 normal;
varying vec4 ambient;
varying float fogMix;
varying float isWater;
varying float isIce;
varying float waterTexStrength;
varying float torchStrength;

#ifdef HAND_DYNAMIC_LIGHTING
   uniform int heldBlockLightValue;
#endif

#include "/common/math.glsl"
#include "/common/getTorchColor.fsh"

uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform sampler2D colortex1;
uniform sampler2D colortex7;
uniform sampler2D depthtex0;
#include "/common/transformations.fsh"

#if REFLECTIONS > 0
#include "/common/getReflectionColor.fsh"
#endif

uniform float frameTimeCounter;
uniform sampler2D noisetex;
uniform sampler2D depthtex1;
uniform float near, far;
uniform float viewWidth, viewHeight;
uniform vec3 sunPosition, moonPosition;
uniform mat4 gbufferModelViewInverse;
uniform int worldTime;
uniform float rainStrength;

float getLinearDepth(float depth) {
    return (2.0 * near * far) / (far + near - (2.0 * depth - 1.0) * (far - near));
}

uniform vec3 cameraPosition;

void main() {
   vec2 screenPos = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
   float opaqueDepth = texture2D(depthtex1, screenPos).r;
   float waterDepth = gl_FragCoord.z;
   
   float depthDiff = max(0.0, getLinearDepth(opaqueDepth) - getLinearDepth(waterDepth));
   float absorption = 1.0 - exp(-depthDiff * 0.15);

   vec4 albedo  = texture2D(texture, texUV);
   vec4 ambientColor = ambient;
   vec4 vertColor   = color;

   #if MC_VERSION >= 11300
      if (isWater > 0.5) {
         vec3 waterColor = vec3(WATER_BRIGHTNESS * max(vec3(1.0), contrast(albedo.rgb, 3.2*waterTexStrength)));
         float viewDist = clamp(length(worldPos) / 48.0, 0.0, 1.0);
         vec3 tint = mix(vec3(0.3, 0.8, 0.8), vec3(0.1, 0.4, 0.9), viewDist);
         waterColor *= tint * 0.9;
         albedo.rgb = mix(waterColor, waterColor * 0.5, absorption);
      }
      #define WATER_BUFFER vertColor
   #else
      #define WATER_BUFFER albedo
   #endif

   vec2 waterBA = min(WATER_BUFFER.ba, vec2(max(WATER_BUFFER.r, WATER_BUFFER.g)*WATER_B, WATER_A));
   WATER_BUFFER.ba = mix(WATER_BUFFER.ba, waterBA, isWater);

   ambientColor.rgb += 0.5*getTorchColor(ambientColor.rgb);
   albedo *= vertColor * ambientColor;

   vec3 waterFogColor = vec3(0.02, 0.35, 0.55);
   if (isEyeInWater == 1) {
       float uDepth = clamp(length(worldPos) / 32.0, 0.0, 1.0);
       waterFogColor = mix(vec3(0.1, 0.6, 0.7), vec3(0.01, 0.15, 0.4), uDepth);
   }

   vec3 baseFogColor = fogColor;
   #ifdef FOG_ENHANCEMENT
      float fogLuminance = luma(fogColor);
      vec3 goldTint = vec3(1.1, 0.95, 0.7) * fogColor;
      baseFogColor = mix(fogColor, goldTint, smoothstep(0.3, 0.8, fogLuminance));
   #endif

   vec3 finalFogColor = mix(baseFogColor, waterFogColor, float(isEyeInWater == 1) * 0.85);
   float finalFogMix  = mix(fogMix, fogMix * 0.75, float(isEyeInWater == 1));
   
   albedo.rgb = mix(albedo.rgb, finalFogColor, finalFogMix);

   vec4 fragNormal = normal;
   #ifdef REALISTIC_WAVES
      if (isWater > 0.5) {
         vec3 absPos = worldPos + cameraPosition;
         vec3 decodedNormal = fragNormal.xyz * 2.0 - 1.0;
         
         if (abs(decodedNormal.y) > 0.8) {
            float speed = frameTimeCounter * 0.025 * WATER_WAVE_SPEED;
            vec3 wavePos = vec3(absPos.xz, absPos.y);
            
            vec2 basePos = wavePos.xy - wavePos.z * 0.2;
            vec2 wave1 = texture2D(noisetex, basePos * 0.05 + vec2(speed)).rg - 0.5;
            vec2 wave2 = texture2D(noisetex, basePos * 0.03125 - speed).rg - 0.5;
            vec2 wave3 = (texture2D(noisetex, basePos * 0.125 + vec2(speed, -speed)).rg - 0.5) * 0.66;
            
            float waveStrength = float(WATER_WAVE_SIZE) * 0.1;
            vec3 finalWave = normalize(vec3((wave1 + wave2 + wave3) * waveStrength, 1.0));
            
            mat3 tbn = mat3(vec3(1,0,0), vec3(0,0,1), vec3(0,1,0));
            decodedNormal = normalize(finalWave * tbn);
            fragNormal.xyz = decodedNormal * 0.5 + 0.5;
         }
      }
   #endif

   if (isWater > 0.5 || isIce > 0.5) {
      vec3 lightDir = normalize(worldTime < 13000 ? sunPosition : moonPosition);
      lightDir = mat3(gbufferModelViewInverse) * lightDir;
      vec3 viewDir = normalize(worldPos);
      vec3 n = normalize(fragNormal.xyz * 2.0 - 1.0);
      
      float fresnel = pow(1.0 - max(0.0, dot(n, -viewDir)), 2.0);
      
      vec3 reflectDir = reflect(viewDir, n);
      vec3 rNorm = normalize(reflectDir);
      vec3 diff = rNorm - lightDir;
      vec3 tangent = normalize(cross(lightDir, vec3(0.0, 1.0, 0.0)));
      vec3 bitangent = normalize(cross(lightDir, tangent));
      float du = dot(diff, tangent);
      float dv = dot(diff, bitangent);
      float sqDist = max(abs(du), abs(dv));
      float coreFalloff = 1.0 - smoothstep(0.0, 0.045, sqDist);
      float core = smoothstep(0.055, 0.035, sqDist) * coreFalloff * 0.7 + smoothstep(0.055, 0.04, sqDist) * 0.3;
      float glow = exp(-sqDist * sqDist * 180.0) * 0.4;
      float specular = (core + glow) * (1.0 - rainStrength) * 2.5;
      vec3 specColor = (worldTime < 13000 ? vec3(1.0, 0.92, 0.8) : vec3(0.8, 0.88, 1.0)) * specular;
      
      albedo.rgb = mix(albedo.rgb, finalFogColor, fresnel * 0.7);
      albedo.rgb += specColor;
      albedo.a = mix(0.3, 0.9, absorption);
      albedo.a = mix(albedo.a, 1.0, fresnel);
   }

   /* DRAWBUFFERS:067 */
   gl_FragData[0] = albedo;
   gl_FragData[1] = fragNormal;
   gl_FragData[2] = vec4(1.0, max(isWater, isIce), 0.0, 1.0);
}