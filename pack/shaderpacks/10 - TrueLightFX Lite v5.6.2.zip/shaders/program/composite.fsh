#define composite
#include "/shader.h"

uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;

uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

vec4 computeTAARejection(vec3 cColor, vec3 pColor, vec3 nU, vec3 nD, vec3 nL, vec3 nR, vec3 nUL, vec3 nUR, vec3 nDL, vec3 nDR) {
    vec3 cSum = cColor + nU + nD + nL + nR + nUL + nUR + nDL + nDR;
    vec3 cSumSq = cColor * cColor + nU * nU + nD * nD + nL * nL + nR * nR + nUL * nUL + nUR * nUR + nDL * nDL + nDR * nDR;
    
    vec3 cAvg = cSum * 0.11111111111;
    vec3 cVar = abs(cSumSq * 0.11111111111 - cAvg * cAvg);
    vec3 cStd = sqrt(cVar);
    
    vec3 minCol = cAvg - cStd;
    vec3 maxCol = cAvg + cStd;
    
    return vec4(clamp(pColor, minCol, maxCol), distance(minCol, maxCol));
}

void main() {
    vec3 outColor = texture2D(colortex0, texcoord).rgb;
    
    float zDepth = texture2D(depthtex0, texcoord).r;
    vec2 pUv = texcoord;
    
    if(zDepth < 1.0) {
        vec3 viewPos = vec3(vec2(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y) * (texcoord * 2.0 - 1.0) + gbufferProjectionInverse[3].xy, gbufferProjectionInverse[3].z);
        viewPos /= (gbufferProjectionInverse[2].w * (zDepth * 2.0 - 1.0) + gbufferProjectionInverse[3].w);
        vec3 footPos = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
        
        vec3 prevFootPos = footPos + cameraPosition - previousCameraPosition;
        vec3 prevViewPos = mat3(gbufferPreviousModelView) * prevFootPos + gbufferPreviousModelView[3].xyz;
        
        vec2 fPos = vec2(gbufferPreviousProjection[0].x, gbufferPreviousProjection[1].y) * prevViewPos.xy + gbufferPreviousProjection[3].xy;
        pUv = (fPos / -prevViewPos.z) * 0.5 + 0.5;
    }


    #ifdef TAA
        bool taaActive = false;
        if (zDepth > 0.56 && pUv.x >= 0.0 && pUv.x <= 1.0 && pUv.y >= 0.0 && pUv.y <= 1.0) {
            taaActive = true;
            vec3 prevHistory = texture2D(colortex3, pUv).rgb;
            
            vec2 pSize = vec2(1.0 / viewWidth, 1.0 / viewHeight);
            vec3 lColor = texture2D(colortex0, texcoord + vec2(-pSize.x, 0.0)).rgb;
            vec3 rColor = texture2D(colortex0, texcoord + vec2(pSize.x, 0.0)).rgb;
            vec3 uColor = texture2D(colortex0, texcoord + vec2(0.0, pSize.y)).rgb;
            vec3 dColor = texture2D(colortex0, texcoord + vec2(0.0, -pSize.y)).rgb;
            vec3 ulColor = texture2D(colortex0, texcoord + vec2(-pSize.x, pSize.y)).rgb;
            vec3 urColor = texture2D(colortex0, texcoord + vec2(pSize.x, pSize.y)).rgb;
            vec3 dlColor = texture2D(colortex0, texcoord + vec2(-pSize.x, -pSize.y)).rgb;
            vec3 drColor = texture2D(colortex0, texcoord + vec2(pSize.x, -pSize.y)).rgb;
            
            vec3 colMax = max(max(max(lColor, rColor), dColor), max(uColor, max(ulColor, max(urColor, max(dlColor, max(drColor, outColor))))));
            vec3 colMin = min(min(min(lColor, rColor), dColor), min(uColor, min(ulColor, min(urColor, min(dlColor, min(drColor, outColor))))));
            
            vec4 historyConstrained = computeTAARejection(outColor, prevHistory, uColor, dColor, lColor, rColor, ulColor, urColor, dlColor, drColor);
            
            float diffPond = clamp((distance(colMax, colMin) - historyConstrained.a) / historyConstrained.a, 0.0, 1.0);
            
            float blendFactor = 0.99 - (smoothstep(0.0, 1.0, diffPond) * 0.33);
            
            vec3 taaResult = mix(outColor, historyConstrained.rgb, blendFactor);
            
            gl_FragData[1] = vec4(clamp(taaResult, 0.0, 50.0), 1.0);
            
            outColor = mix(outColor, taaResult, TAA_STRENGTH);
        }
    #endif

    #ifdef MOTION_BLUR
        float depth = texture2D(depthtex0, texcoord).r;
        if (depth > 0.56) {
            vec2 mbUv = texcoord;
            vec3 viewPos = vec3(vec2(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y) * (texcoord * 2.0 - 1.0) + gbufferProjectionInverse[3].xy, gbufferProjectionInverse[3].z);
            viewPos /= (gbufferProjectionInverse[2].w * (depth * 2.0 - 1.0) + gbufferProjectionInverse[3].w);
            vec3 footPos = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
            
            vec3 prevFootPos = footPos + (depth < 1.0 ? cameraPosition - previousCameraPosition : vec3(0.0));
            vec3 prevViewPos = mat3(gbufferPreviousModelView) * prevFootPos + gbufferPreviousModelView[3].xyz;
            
            vec2 fPos = vec2(gbufferPreviousProjection[0].x, gbufferPreviousProjection[1].y) * prevViewPos.xy + gbufferPreviousProjection[3].xy;
            mbUv = (fPos / -prevViewPos.z) * 0.5 + 0.5;

            vec2 velocity = (texcoord - mbUv) * MOTION_BLUR_INTENSITY;
            vec3 blurColor = outColor;
            float totalWeight = 1.0;
            
            for (int i = 1; i <= 4; i++) {
                vec2 offsetUV = texcoord - velocity * (float(i) / 4.0);
                if (offsetUV.x >= 0.0 && offsetUV.x <= 1.0 && offsetUV.y >= 0.0 && offsetUV.y <= 1.0) {
                    blurColor += texture2D(colortex0, offsetUV).rgb;
                    totalWeight += 1.0;
                }
            }
            outColor = blurColor / totalWeight;
        }
    #endif

    /* DRAWBUFFERS:13 */
    gl_FragData[0] = vec4(clamp(outColor, 0.0, 50.0), 1.0);
    #ifdef TAA
        if (!taaActive) {
            gl_FragData[1] = vec4(clamp(outColor, 0.0, 50.0), 1.0);
        }
    #else
        gl_FragData[1] = vec4(clamp(outColor, 0.0, 50.0), 1.0);
    #endif
}
