#define gbuffers_basic

#include "/shader.h"

uniform float frameTimeCounter;

varying vec2 texUV;
varying vec4 vertColor;
varying vec2 screenPos;

uniform vec2 taaOffset;

void main() {
   gl_Position = ftransform();

   #ifdef TAA
      gl_Position.xy += taaOffset * gl_Position.w;
   #endif

   texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
   vertColor = gl_Color;
   screenPos = gl_Position.xy / gl_Position.w;
}
