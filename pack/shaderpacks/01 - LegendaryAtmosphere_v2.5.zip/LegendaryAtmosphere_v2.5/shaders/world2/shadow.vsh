/* 
BSL Shaders v10 Series by Capt Tatsu 
https://capttatsu.com 
*/ 

#version 130

#define OVERWORLD
#define AIRSHIP
#define VSH

#include "/program/shadow.glsl"
