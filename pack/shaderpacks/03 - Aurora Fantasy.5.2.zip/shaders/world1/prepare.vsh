#version 120
/* Aurora Fantasy - prepare.vsh
Render: Sky

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define THE_END
#define PREPARE_SHADER
#define NO_SHADOWS

#include "/common/prepare_vertex.glsl"