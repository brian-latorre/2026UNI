#version 120
/* Aurora Fantasy - gbuffers_water.fsh
Render: Water and translucent blocks

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define NETHER
#define GBUFFER_WATER
#define WATER_F
#define NO_SHADOWS

#include "/common/water_blocks_fragment.glsl"
